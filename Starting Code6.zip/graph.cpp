#include "graph.h"

// Constructor/Destructor for Graph.
Graph::Graph() {

}
Graph::~Graph() {

}

// Loads the graph.
void Graph::LoadGraph(char *graphFileName) {

}

// Runs Dijkstra's algorithm, using the specified vertex as the starting vertex.
void Graph::RunDijkstra(char startVertex) {

}

// Returns the distance of the vertex with the specified name from the starting vertex.
int Graph::GetDistance(char vertex) {

}

// Returns the number of updates made to the vertex's distance during the last call of RunDijkstra.
int Graph::GetNumberOfUpdates(char vertex);
