#ifndef INFINITY_H
#define INFINITY_H

// Returns the current value of infinity.
int GetINFINITY();

#endif